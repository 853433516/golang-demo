package installer_hook

import (
	"SeoControl/constant"
	"SeoControl/global"
	"SeoControl/internal/dto"
	"SeoControl/internal/dto/rpcx_dto"
	"SeoControl/internal/model"
	"SeoControl/internal/repo"
	"SeoControl/internal/service"
	"SeoControl/pkg/event"
	"SeoControl/pkg/installer/apps"
	"SeoControl/pkg/rpcx"
	"SeoControl/pkg/utils/copier"
	"SeoControl/pkg/utils/hashids"
	"encoding/json"
	"fmt"
	"github.com/smallnest/rpcx/log"
	"go.uber.org/zap"
	"os"
	"strconv"
	"time"
)

func ReplaceConfig(status uint, host model.Host) error {
	var (
		fluentConfig = apps.FluentBitConfig
		addr         = host.Addr
		err          error
	)
	switch status {
	case model.HostServerCompleted: // 完成安装切换配置
		for {
			fluentConfig, err = apps.GetNewFluentBitConfig(fluentConfig, strconv.Itoa(global.Viper.Server.Port), addr, global.Viper.Server.Tls.Enable)
			if err != nil {
				log.Errorf("安装回调获取配置失败:%v", zap.Error(err))
				time.Sleep(time.Second * 5)
				continue
			}

			service.WebSiteBackUpService.SyncthingSetting(&host)

			result, _ := hashids.Encode(strconv.Itoa(int(host.ID)))
			_, err = event.WaitForResult(global.EventPool.Dispatch(constant.EventRPCX, rpcx.InvokeParams{
				Host:          host.Addr,
				ServiceName:   "Website",
				ServiceMethod: "SyncConfigHostId",
				InvokeArgs: struct {
					HostId string `json:"host_id"`
				}{
					HostId: result,
				},
				InvokeReply: nil,
			}))
			// 同步模板配置
			for _, name := range [4]string{"link.dat", "anti.dat", "403.dat", "404.dat"} {
				tp := 0
				data, err := os.ReadFile(fmt.Sprintf("/www/data/%s", name))
				if err != nil {
					continue
				}
				switch name {
				case "link.dat":
					tp = dto.LINK
				case "anti.dat":
					tp = dto.ANTI
				case "403.dat":
					tp = dto.HTML403
				case "404.dat":
					tp = dto.HTML404
				}
				_, err = event.WaitForResult(global.EventPool.Dispatch(constant.EventRPCX, rpcx.InvokeParams{
					Host:          host.Addr,
					ServiceName:   "Website",
					ServiceMethod: "UpdateWebSiteTemplate",
					InvokeArgs: rpcx_dto.UpdateWebsiteParamArgs{
						FilePath: name,
						Content:  string(data),
						AntiType: uint(tp),
						Global:   true,
					},
					InvokeReply: nil,
				}))
				if err != nil {
					continue
				}
			}

			//针对新添加的机器添加socket连接
			service.NewMessage.PushHostToQueue(host)

			err := apps.UpdateFluentBitConfig(fluentConfig, addr)
			log.Errorf("执行结果: %v", err)
			return err
		}
	}
	return err
}

// InitInstallerHook 注册安装完成钩子
func InitInstallerHook() {
	service.HostService.RegisterHook(ReplaceConfig)
	go service.NewMessage.ClientLink()
}

func initAddSocket(host model.Host) {
	var resultReq service.DashboardLogsReq
	resultReq.Addr = host.Addr
	resultReq.UserId = host.UserID
	//var resultBack DashboardLogs
	//获取客户机所有ip
	ctx, chn := global.EventPool.Dispatch(constant.EventRPCX, rpcx.InvokeParams{
		Host:          host.Addr,
		ServiceName:   "Dashboard",
		ServiceMethod: "DashboardLogs",
		InvokeArgs:    resultReq,
		InvokeReply:   &service.DashboardLogs{},
		KeepAlive:     true,
	})
loop:
	for {
		select {
		case value := <-chn:
			if value.Error != nil {
				fmt.Println("value.Error:", value.Error)
				goto loop
			}
			var resultBack service.DashboardLogs
			var dashboardLog model.MessageLog
			data := value.Result.([]byte)
			json.Unmarshal(data, &resultBack)
			//fmt.Printf("=====%+v", resultBack)
			copier.Copy(&dashboardLog, resultBack)
			if len(data) > 0 {
				err := repo.MessageLogRepo.Create(&dashboardLog)
				if err != nil {
					fmt.Println("error", err)
					goto loop
				}
			}

		case <-ctx.Done(): // TODO Finish
			break loop
		}
	}
}
