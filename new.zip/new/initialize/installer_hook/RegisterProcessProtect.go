package installer_hook

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const (
	MasterStartShell = `[Unit]
Description=gpanel
After=network.target

[Service]
Type=simple
User=root
Group=root
ExecStart={{execFile}}
WorkingDirectory={{workDir}}
Restart=always
TimeoutStopSec=10
KillMode=mixed
KillSignal=SIGKILL

[Install]
WantedBy=multi-user.target
`
)

// RegisterProcessProtect 为群控添加进程守护
func RegisterProcessProtect() {
	var (
		masterStartShell string
		filePath, err    = os.Executable()
	)
	if err != nil {
		log.Printf("进程守护安装错误: %v", err)
		return
	}
	if _, err = os.Stat("/usr/lib/systemd/system/gpanel.service"); err == nil {
		if content, err := os.ReadFile("/usr/lib/systemd/system/gpanel.service"); err == nil {
			if strings.Index(string(content), "TimeoutStopSec") > -1 {
				return
			}
		}
	}
	masterStartShell = strings.ReplaceAll(MasterStartShell, "{{execFile}}", filePath)
	masterStartShell = strings.ReplaceAll(masterStartShell, "{{workDir}}", filepath.Dir(filePath))
	os.WriteFile("/usr/lib/systemd/system/gpanel.service", []byte(masterStartShell), 0666)
	exec.Command("bash", "-c", fmt.Sprintf("sudo ln -s %s /usr/local/bin/gpanel", filePath)).Run()
	exec.Command("bash", "-c", "sudo chmod +x /usr/local/bin/gpanel")
	exec.Command("bash", "-c", "sudo systemctl daemon-reload").Run()
	exec.Command("bash", "-c", "sudo systemctl enable gpanel").Run()
	exec.Command("bash", "-c", "sudo systemctl restart gpanel").Start()
	os.Exit(1)
}
