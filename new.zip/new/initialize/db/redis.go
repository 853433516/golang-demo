package db

import (
	"PayOrder/global"
	"context"
	"fmt"

	"github.com/redis/go-redis/v9"
)

func InitRedis() {
	redisConf := global.Viper.Redis
	if redisConf == nil {
		global.LOG.Panic("未找到redis配置信息")
	}
	rdb := redis.NewClient(&redis.Options{
		Addr:     fmt.Sprintf("%s:%d", redisConf.Host, redisConf.Port),
		Password: redisConf.Password, // no password set
		DB:       redisConf.Db,       // use default DB
	})
	// 测试连接
	_, e := rdb.Ping(context.TODO()).Result()
	if e != nil {
		panic(fmt.Sprintf("连接redis失败! [%s:%d]", redisConf.Host, redisConf.Port))
	}
	global.Redis = rdb
}
