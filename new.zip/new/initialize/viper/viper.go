package viper

import (
	"PayOrder/global"
	"PayOrder/initialize/viper/config"
	"fmt"
)

func InitViper() {

	c := &config.Config{}

	// 初始化配置文件`
	if err := c.InitViper(); err != nil {
		panic(fmt.Sprintf("读取配置文件失败: %s", err.Error()))
	}
	// 监控配置文件变化并热加载程序
	c.WatchConfig()
	global.Viper = c
	//fmt.Printf("系统版本: %s\n", version.Version)
	//fmt.Printf("用户名称: %s\n", global.Viper.SuperUser.UserName)
	//fmt.Printf("用户密码: %s\n", global.Viper.SuperUser.UserPassword)
	fmt.Printf("\n")
	fmt.Printf("如果使用的是云服务器，请至安全组开放 %d 端口\n", global.Viper.Server.Port)
}
