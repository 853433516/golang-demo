package config

import (
	"PayOrder/constant"
	"errors"
	"fmt"
	"log"
	"os"
	"path"
	"path/filepath"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
	"gopkg.in/yaml.v3"
)

type PublicIpResp struct {
	Code int    `json:"code"`
	Data string `json:"data"`
	Msg  string `json:"msg"`
}

type Config struct {
	WebmasterCode string  `yaml:"webmaster_code"`
	Server        *Server `yaml:"server"`
	Jwt           *Jwt    `yaml:"jwt"`
	Mysql         *Mysql  `yaml:"mysql"`
	//Sqlite          *Sqlite          `yaml:"sqlite"`
	Redis *Redis `yaml:"redis"`
	Log   *Log   `yaml:"log"`
	//SuperUser       *SuperUser       `yaml:"super"`
	//Security        *Security        `yaml:"security"`
	//Website         *Website         `yaml:"website"`
}

// WatchConfig 监控配置文件变化并热加载程序
func (c *Config) WatchConfig() {
	viper.WatchConfig()
	viper.OnConfigChange(func(e fsnotify.Event) {
		log.Printf("Config file changed: %s", e.Name)
	})
}

// WriteConfig 修改并写入配置
func (c *Config) WriteConfig() error {
	path_, _ := filepath.Abs(path.Join(constant.SystemConfigDirPath, "config.yml"))
	if data, err := yaml.Marshal(c); err != nil {
		return err
	} else {
		return os.WriteFile(path_, data, 0666)
	}
}

// 从指定路径加载yaml文件
func (c *Config) LoadYml(path string, out any) error {
	yamlFileBytes, readErr := os.ReadFile(path)
	if readErr != nil {
		return readErr
	}
	// yaml解析
	err := yaml.Unmarshal(yamlFileBytes, out)
	if err != nil {
		return errors.New("无法解析 [" + path + "] -- " + err.Error())
	}
	return nil
}

func (c *Config) LoadYmlByString(yamlStr string, out any) error {
	// yaml解析
	return yaml.Unmarshal([]byte(yamlStr), out)
}

//
//func (c *Config) PublicIP() {
//	client := &http.Client{
//		Transport: &http.Transport{
//			TLSClientConfig: &tls.Config{
//				InsecureSkipVerify: true,
//			},
//			TLSHandshakeTimeout:   10 * time.Second,
//			MaxIdleConns:          100,
//			IdleConnTimeout:       10 * time.Second,
//			ResponseHeaderTimeout: 10 * time.Second,
//			ExpectContinueTimeout: 10 * time.Second,
//		},
//		Timeout: 30 * time.Second,
//	}
//	req, _ := http.NewRequest(http.MethodGet, constant.PublicApi, nil)
//	req.Header.Set("User-Agent", fmt.Sprintf("self-web-health-checking/%s", version.Version))
//	response, err := client.Do(req)
//	if err != nil {
//		log.Println(err)
//		return
//	}
//	defer response.Body.Close()
//	var ip PublicIpResp
//
//	bodyBytes, err := io.ReadAll(response.Body)
//	err = json.Unmarshal(bodyBytes, &ip)
//	if err != nil {
//		log.Println(err)
//		return
//	}
//	c.Server.PublicIp = ip.Data
//	c.WriteConfig()
//}

func (c *Config) InitViper() error {
	path_, _ := filepath.Abs(constant.SystemConfigPath)
	if err := c.LoadYml(path_, c); err != nil {
		panic(fmt.Sprintf("读取配置文件[%s]失败: %s", path_, err.Error()))
	}
	if c.Server.SlavePort == 0 { // 如果SlavePort等于0则使用8971
		c.Server.SlavePort = 8971
		err := c.WriteConfig()
		if err != nil {
			return err
		}
	}

	viper.AddConfigPath(constant.SystemConfigDirPath) // 如果没有指定配置文件，则解析默认的配置文件
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")                  // 设置配置文件格式为YAML
	viper.AutomaticEnv()                         // 读取匹配的环境变量
	if err := viper.ReadInConfig(); err != nil { // viper解析配置文件
		return err
	}
	return nil

}
