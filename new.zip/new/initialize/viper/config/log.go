package config

type Log struct {
	Level      string `yaml:"level"`
	Encoding   string `yaml:"encoding"`
	LogFile    string `yaml:"log_file"`
	MaxBackups int    `yaml:"max_backups"`
	MaxAge     int    `yaml:"max_age"`
	MaxSize    int    `yaml:"max_size"`
	Compress   bool   `yaml:"compress"`
}
