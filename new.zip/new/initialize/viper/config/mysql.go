package config

type Mysql struct {
	Host         string `yaml:"host"`
	Username     string `yaml:"username"`
	Password     string `yaml:"password"`
	DbName       string `yaml:"db-name"`
	Config       string `yaml:"config"`
	MaxIdleConns int    `yaml:"max-idle-conns"`
}

func (m *Mysql) Dsn(dbName string) string {
	return m.Username + ":" + m.Password + "@tcp(" + m.Host + ")/" + dbName + "?" + m.Config
}
