package config

import "fmt"

type Server struct {
	UseMultipoint bool   `json:"use-multipoint"`
	Port          int    `yaml:"port"`
	PortSsl       int    `yaml:"port_ssl"`
	SlavePort     int    `yaml:"slave_port" default:"8971"`
	Model         string `yaml:"model"`
	Cors          bool   `yaml:"cors"`
	Tls           *Tls   `yaml:"tls"`
	TmpDir        string `yaml:"tmpDir"`
	BaseDir       string `yaml:"baseDir"`
	PublicIp      string `yaml:"public_ip"`
	AuthUrl       string `yaml:"auth_url"`
	Domain        string `yaml:"domain"`
	TargetVersion string `yaml:"target_version"`
}

func (s *Server) GetPort() string {
	return fmt.Sprintf(":%d", s.Port)
}

type Tls struct {
	EnableTmp bool   `yaml:"enable_tmp"` // 是否启用tls
	Enable    bool   `yaml:"enable"`     // 是否启用tls
	KeyFile   string `yaml:"key-file"`   // 私钥文件路径
	CertFile  string `yaml:"cert-file"`  // 证书文件路径
}
