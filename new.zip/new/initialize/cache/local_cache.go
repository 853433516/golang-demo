package cache

import (
	"PayOrder/global"
	"PayOrder/pkg/utils/common"

	"github.com/songzhibin97/gkit/cache/local_cache"
)

func InitLocalCache() {
	dr, err := common.ParseDuration(global.Viper.Jwt.ExpiresTime)
	if err != nil {
		panic(err)
	}
	_, err = common.ParseDuration(global.Viper.Jwt.BufferTime)
	if err != nil {
		panic(err)
	}

	global.BlackCache = local_cache.NewCache(
		local_cache.SetDefaultExpire(dr),
	)
	// 初始化QQZeng IP数据库
	//global.QQZengIpSearcher = qqzeng.NewQQZeng()
	//go global.QQZengIpSearcher.Init()
}
