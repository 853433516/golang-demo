package migrations

import (
	"PayOrder/global"
	"PayOrder/internal/model"
	"fmt"

	"github.com/go-gormigrate/gormigrate/v2"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var AddTableMenuResource = &gormigrate.Migration{
	ID: fmt.Sprintf("%s-add-table-SysUser-log", ID),
	Migrate: func(tx *gorm.DB) error {
		if err := tx.AutoMigrate(&model.SysUser{}); err != nil {
			global.LOG.Error("Menu自动建表失败!", zap.Error(err))
			return err
		}

		//var apis []model.SysMenuResource
		//err := tx.Raw("select * from sys_menu_resource").Scan(&apis).Error
		//entities := []model.SysMenuResource{}
		//if err == nil {
		//	if len(apis) == 0 {
		//		if err := tx.Create(&entities).Error; err != nil {
		//			global.LOG.Error("生成Api数据错误", zap.Error(err))
		//			return err
		//		}
		//	}
		//}
		return nil
	},
}
