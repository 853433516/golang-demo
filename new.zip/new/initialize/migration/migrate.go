package migration

import (
	"PayOrder/global"
	"PayOrder/initialize/migration/migrations"
	"log"

	"github.com/go-gormigrate/gormigrate/v2"
	"go.uber.org/zap"
)

func InitMigrate() {
	buss := gormigrate.New(global.DBName(global.Buss), gormigrate.DefaultOptions, []*gormigrate.Migration{
		migrations.AddTableMenuResource,
	})

	if err := buss.Migrate(); err != nil {
		global.LOG.Error("自动建表失败!", zap.Error(err))
	}

	//logM := gormigrate.New(global.DBName(global.Log), gormigrate.DefaultOptions, []*gormigrate.Migration{
	//	migrations.AddTableOperationLog,
	//	migrations.AddTableNginxLog,
	//	migrations.AddTableTaskLog,
	//	migrations.AddTableSeoLog,
	//	migrations.AddTableSeoInfoLog,
	//	migrations.AddTableSeoInfoLogFromCron,
	//})
	//if err := logM.Migrate(); err != nil {
	//	global.LOG.Error("自动建表失败!", zap.Error(err))
	//}
	log.Println("Migration run successfully")
}
