package router

import (
	"PayOrder/global"
	"PayOrder/middleware"
	"fmt"

	"github.com/gin-contrib/gzip"
	"github.com/gin-gonic/gin"
)

func routers() *gin.Engine {
	//gin.SetMode(gin.DebugMode)
	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(middleware.Cors())
	router.Use(gzip.Gzip(gzip.DefaultCompression))
	//setWebStatic(router)
	router.Use(middleware.GinRecovery(true))

	V2Router(router)
	return router
}

func InitRouter() {
	rootRouter := routers()

	//rootRouter.NoRoute(func(c *gin.Context) {
	//	accept := c.Request.Header.Get("Accept")
	//	flag := strings.Contains(accept, "text/html")
	//	if flag {
	//		content, err := ioutil.ReadFile("/www/server/static/index.html")
	//		if (err) != nil {
	//			c.Writer.WriteHeader(404)
	//			c.Writer.WriteString("Not Found")
	//			return
	//		}
	//		c.Writer.WriteHeader(200)
	//		c.Writer.Header().Add("Accept", "text/html")
	//		c.Writer.Write(content)
	//		c.Writer.Flush()
	//	}
	//})
	//address = ":8081"
	//fmt.Println("address:", address)
	address := fmt.Sprintf(":%d", global.Viper.Server.Port)
	if !global.Viper.Server.Tls.Enable {
		err := rootRouter.Run(address)
		if err != nil {
			global.LOG.Error(fmt.Sprintf("http服务启动失败%v", err))
			return
		}
	} else {
		err := rootRouter.RunTLS(address, global.Viper.Server.Tls.CertFile, global.Viper.Server.Tls.KeyFile)
		if err != nil {
			global.LOG.Error(fmt.Sprintf("https服务启动失败%v", err))
			return
		}
	}
	//global.LOG.Info(fmt.Sprintf("端口:%d已经被占用", global.Viper.Server.Port))
}
