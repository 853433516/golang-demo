package router

import (
	"PayOrder/router"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

func V2Router(r *gin.Engine) {
	PrivateGroup := r.Group("/api/v1")
	PrivateGroup.GET("swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	PrivateGroup.Use(gin.Logger())
	systemRouter := router.RouterGroupApp
	{
		systemRouter.InitAlertRouter(PrivateGroup) //告警设置
		systemRouter.InitAuthRouter(PrivateGroup)  //告警设置
	}
}
