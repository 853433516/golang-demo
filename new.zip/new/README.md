
```
编译命令
1.查看支持架构
go tool dist list | grep linux

Windows x86_64
CGO_ENABLED=0 GOOS=windows  GOARCH=amd64 go build -ldflags "-s -w" -o ./payorder-windows-amd64.exe

Windows i386
CGO_ENABLED=0 GOOS=windows GOARCH=386 go build -ldflags "-s -w" -o ./payorder-windows-386.exe

Linux x86_64
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags "-s -w" -o ./payorder-linux-amd64

Linux arm64
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -ldflags "-s -w" -o ./payorder-linux-arm64

Linux i386
CGO_ENABLED=0 GOOS=linux GOARCH=386 go build -ldflags "-s -w" -o ./payorder-linux-386

Mac x86_64(适用m1芯片之前)
CGO_ENABLED=0 GOOS=darwin GOARCH=amd64 go build -ldflags "-s -w" -o ./payorder-macos-amd64

Mac arm64(适用m1/m2芯片)
CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 go build -ldflags "-s -w" -o ./payorder-macos-arm64


```

#swag文档方式
`
本地命令行 swag init
import (
swaggerfiles "github.com/swaggo/files"
ginSwagger "github.com/swaggo/gin-swagger"
)
swaggerRouter := Router.Group("doc")
docs.SwaggerInfo.BasePath = "/api/v1"
swaggerRouter.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerfiles.Handler))
`
