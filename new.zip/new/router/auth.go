package router

import (
	"PayOrder/internal/api"

	"github.com/gin-gonic/gin"
)

type AuthRouter struct{}

func (s *AuthRouter) InitAuthRouter(Router *gin.RouterGroup) {
	baseRouter := Router.Group("auth")
	baseApi := api.ApiGroupApp.AuthApi
	{
		baseRouter.POST("/login", baseApi.Login)
		baseRouter.GET("/user", baseApi.LogOut)
		baseRouter.POST("/logout", baseApi.LogOut)
	}
}
