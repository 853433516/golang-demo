package router

import (
	"PayOrder/internal/api"
	"PayOrder/middleware"

	"github.com/gin-gonic/gin"
)

type AlertRouter struct {
}

func (f *AlertRouter) InitAlertRouter(Router *gin.RouterGroup) {
	fileRouter := Router.Group("alert").
		Use(middleware.JWTAuth()).
		//Use(middleware.OperationLog()).
		Use(middleware.CasbinHandler())
	baseApi := api.ApiGroupApp.AlertApi
	{
		fileRouter.GET("/", baseApi.GetAlertConfig)
	}
}
