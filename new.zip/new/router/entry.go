package router

type RouterGroup struct {
	AlertRouter
	AuthRouter
}

var RouterGroupApp = new(RouterGroup)
