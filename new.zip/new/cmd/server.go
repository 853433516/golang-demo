package cmd

import (
	_ "PayOrder/docs"
	"PayOrder/global"
	"PayOrder/initialize/cache"
	"PayOrder/initialize/log"
	"PayOrder/initialize/router"
	"PayOrder/initialize/viper"

	"go.uber.org/zap"
)

func Starter() {
	defer func() {
		if err := recover(); err != nil {
			global.LOG.Error("错误消息:", zap.Error(err.(error)))
		}
	}()
	viper.InitViper()
	log.InitZap() //初始化日志
	//db.InitDb()

	//migration.InitMigrate()

	cache.InitLocalCache()
	router.InitRouter()
}
