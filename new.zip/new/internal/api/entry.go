package api

type ApiGroup struct {
	AlertApi
	AuthApi
}

var ApiGroupApp = new(ApiGroup)
