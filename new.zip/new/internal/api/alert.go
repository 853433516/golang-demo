package api

import (
	"PayOrder/internal/api/common/response"
	"PayOrder/pkg/utils/common"
	"fmt"

	"github.com/gin-gonic/gin"
)

type AlertApi struct{}

// GetAlertConfig @Summary 获取卡片列表
// @Description 获取已支持卡片列表
// @Tags 工作台
// @Produce json
// @Param x-token header string true "令牌"
// @Failure 500 {string} string "500错误"
// @Router /api/workbench-card [get]
func (b *AlertApi) GetAlertConfig(c *gin.Context) {

	userId := common.GetUserID(c)

	fmt.Println("------", userId)
	fmt.Println("------", common.GetUserUuid(c))
	//err := service.AlertSettingService.Create(userId, uint(hostId))
	//if err != nil {
	//	response.FailWithMessage(err.Error(), c)
	//	return
	//}
	response.Ok(c)
}
