package api

import (
	"PayOrder/global"
	"PayOrder/internal/api/common/response"
	"PayOrder/internal/dto"
	"PayOrder/internal/model"
	"PayOrder/internal/service"
	"PayOrder/pkg/utils/common"
	"github.com/gofrs/uuid"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

type AuthApi struct{}

// @Tags Auth
// @Summary 用户登录
// @Accept json
// @Param request body dto.LoginRequest true "request"
// @Success 200 {object} model.SysUser
// @Router /auth/login [post]
func (b *AuthApi) Login(c *gin.Context) {
	//var (
	//	req dto.LoginRequest
	//)
	//if err := c.ShouldBindJSON(&req); err != nil {
	//	response.FailWithMessage(err.Error(), c)
	//	return
	//}

	user := &model.SysUser{}
	user.ID = 1
	user.Username = "aaaaaa"
	user.Password = "bbbbbbbbbbbbb"
	user.UUID = uuid.Must(uuid.NewV4())
	b.TokenNext(c, *user)
	return
}

func (b *AuthApi) TokenNext(c *gin.Context, user model.SysUser) {
	j := &common.JWT{SigningKey: []byte(global.Viper.Jwt.SigningKey)} // 唯一签名
	claims := j.CreateClaims(model.BaseClaims{
		UUID:     user.UUID,
		ID:       user.ID,
		UserID:   user.UserID,
		NickName: user.NickName,
		Username: user.Username,
	})
	token, err := j.CreateToken(claims)
	if err != nil {
		global.LOG.Error("获取token失败!", zap.Error(err))
		response.FailWithMessage("获取token失败", c)
		return
	}
	if !global.Viper.Server.UseMultipoint {
		response.OkWithDetailed(dto.LoginResponse{
			User:      user,
			Token:     token,
			ExpiresAt: claims.RegisteredClaims.ExpiresAt.Unix() * 1000,
		}, "登录成功", c)
		return
	}

	if jwtStr, err := service.JwtService.GetRedisJWT(user.Username); err == redis.Nil {
		if err := service.JwtService.SetRedisJWT(token, user.Username); err != nil {
			global.LOG.Error("设置登录状态失败!", zap.Error(err))
			response.FailWithMessage("设置登录状态失败", c)
			return
		}
		response.OkWithDetailed(dto.LoginResponse{
			User:      user,
			Token:     token,
			ExpiresAt: claims.RegisteredClaims.ExpiresAt.Unix() * 1000,
		}, "登录成功", c)
	} else if err != nil {
		global.LOG.Error("设置登录状态失败!", zap.Error(err))
		response.FailWithMessage("设置登录状态失败", c)
	} else {
		var blackJWT model.JwtBlacklist
		blackJWT.Jwt = jwtStr
		if err := service.JwtService.JsonInBlacklist(blackJWT); err != nil {
			response.FailWithMessage("jwt作废失败", c)
			return
		}
		if err := service.JwtService.SetRedisJWT(token, user.Username); err != nil {
			response.FailWithMessage("设置登录状态失败", c)
			return
		}
		response.OkWithDetailed(dto.LoginResponse{
			User:      user,
			Token:     token,
			ExpiresAt: claims.RegisteredClaims.ExpiresAt.Unix() * 1000,
		}, "登录成功", c)
	}
}

// @Tags Auth
// @Summary User logout
// @Description 用户登出
// @Success 200
// @Security ApiKeyAuth
// @Router /auth/logout [post]
func (b *AuthApi) LogOut(c *gin.Context) {
	if err := service.AuthService.LogOut(c); err != nil {
		response.FailWithMessage(err.Error(), c)
		return
	}
	response.Ok(c)
}
