package request

import "PayOrder/internal/model"

type SysOperationLogSearch struct {
	model.OperationLog
	PageInfo
}
