package request

type PublicReqInfo struct {
	Uuid        string `json:"uuid"  binding:"required"`
	TimeReq     uint   `json:"time_req"  binding:"required"`   //1今天 2 昨天 3 最近七天 4 最近30天
	StartTime   int64  `json:"start_time"  binding:"required"` //开始时间
	EndTime     int64  `json:"end_time"  binding:"required"`   //结束时间
	TimeType    uint   `json:"time_type"`                      //时间类别
	Source      uint   `json:"source"`                         //来源
	Device      uint   `json:"device"`                         //设备
	Visitor     uint   `json:"visitor"`                        //1新访客 2老访客
	RuleReferer string `json:"rule_Referer"`                   //访问来源
	Contrast    uint   `json:"contrast"`                       //对比
	//Size        int    `json:"size"`
	Page           int  `json:"page"`
	Total          int  `json:"total"`
	PageSize       int  `json:"pageSize"`
	ClassIfy       uint `json:"class_ify"` //1折线图
	ClassIfySource uint `json:"classIfySource"`
}

type PublicReqInfoEs struct {
	Uuid           string `json:"uuid"`
	Page           int    `json:"page"`
	PageSize       int    `json:"pageSize"`
	TimeReq        uint   `json:"time_req"`     //1按时 2按日 3 按周 4 按月
	StartTime      int64  `json:"start_time"`   //开始时间
	EndTime        int64  `json:"end_time"`     //结束时间
	TimeType       uint   `json:"time_type"`    //时间类别
	Source         uint   `json:"source"`       //来源
	Device         uint   `json:"device"`       //设备 1全部 2计算机 3移动设备
	Visitor        uint   `json:"visitor"`      //1新访客 2老访客
	RuleReferer    string `json:"rule_Referer"` //访问来源
	Contrast       uint   `json:"contrast"`     //对比  2昨天 5 上周同期
	Size           int    `json:"size"`
	Total          int    `json:"total"`
	ClassIfy       uint   `json:"class_ify"`      //1折线图 2 搜索词 3 来源网站   8 地区分布 省 9 地区分布 全国
	ClassIfySource uint   `json:"classIfySource"` // 当ClassIfy = 3 的时候使用 1 代表来源类型2 代表来源网站
}
