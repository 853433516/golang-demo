package model

import (
	"github.com/gofrs/uuid"
)

type SysUser struct {
	BaseModel
	UUID         uuid.UUID `json:"uuid" gorm:"index;comment:用户UUID"`
	UserID       uint      `json:"userId" gorm:"not null;comment:创建的用户ID;"`
	Username     string    `json:"userName" gorm:"index;comment:用户登录名"`                                                  // 用户登录名
	Password     string    `json:"-"  gorm:"comment:用户登录密码"`                                                             // 用户登录密码
	NickName     string    `json:"nickName" gorm:"default:超管;comment:用户昵称"`                                              // 用户昵称
	SideMode     string    `json:"sideMode" gorm:"default:dark;comment:用户侧边主题"`                                          // 用户侧边主题
	HeaderImg    string    `json:"headerImg" gorm:"default:https://qmplusimg.henrongyi.top/gva_header.jpg;comment:用户头像"` // 用户头像
	BaseColor    string    `json:"baseColor" gorm:"default:#fff;comment:基础颜色"`                                           // 基础颜色
	ActiveColor  string    `json:"activeColor" gorm:"default:#1890ff;comment:活跃颜色"`                                      // 活跃颜色
	Enable       bool      `json:"enable" gorm:"comment:用户是否被冻结"`                                                        //用户是否被冻结 true正常 false冻结
	Permission   uint      `json:"permission" gorm:"default:1;comment:修改权限"`
	ServersNum   uint      `json:"serversNum" gorm:"default:5;comment:允许创建最大服务器数量;"`
	EmployeesNum uint      `json:"employeesNum" gorm:"default:5;comment:允许创建最大员工数量;"`
}

func (SysUser) TableName() string {
	return "sys_users"
}
