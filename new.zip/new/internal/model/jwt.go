package model

import (
	"github.com/gofrs/uuid"
	"github.com/golang-jwt/jwt/v4"
)

// Custom claims structure
type CustomClaims struct {
	BaseClaims
	BufferTime int64
	jwt.RegisteredClaims
}

type BaseClaims struct {
	UUID        uuid.UUID
	ID          uint
	UserID      uint //0 表示超管  1 管理员  其他都是普通用户
	Username    string
	NickName    string
	AuthorityId uint
}
