package model

import (
	"time"
)

type BaseModel struct {
	ID        uint      `gorm:"primary_key;autoIncrement" json:"id"`
	CreatedAt time.Time `json:"createdAt"`
	UpdatedAt time.Time `json:"updatedAt"`
	//DeletedAt gorm.DeletedAt `gorm:"index" json:"-"` // 删除时间
}
