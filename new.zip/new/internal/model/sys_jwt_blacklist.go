package model

type JwtBlacklist struct {
	BaseModel
	Jwt string `gorm:"type:text;comment:jwt"`
}

func (JwtBlacklist) TableName() string {
	return "sys_jwt_blacklist"
}
