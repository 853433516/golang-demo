package service

var (
	JwtService          = newJwtService()
	AlertSettingService = newAlertSettingService()
	OperationLogService = newOperationRecordService()
	AuthService         = newAuthService()
)
