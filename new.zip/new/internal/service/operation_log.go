package service

import (
	"PayOrder/global"
	"PayOrder/internal/api/common/request"
	"PayOrder/internal/model"
)

//@description: 创建记录
//@param: sysOperationRecord model.SysOperationRecord
//@return: err error

type operationRecordService struct{}

type iOperationRecordService interface {
	CreateSysOperationRecord(record model.OperationLog) error
	//Login(c *gin.Context, info dto.Login) (*dto.UserLoginInfo, error)
	//LogOut(c *gin.Context) error
}

func newOperationRecordService() iOperationRecordService {
	return &operationRecordService{}
}

func (operationRecordService *operationRecordService) CreateSysOperationRecord(sysOperationRecord model.OperationLog) (err error) {
	err = global.DBName(global.Log).Create(&sysOperationRecord).Error
	return err
}

//@function: DeleteSysOperationRecordByIds
//@description: 批量删除记录
//@param: ids request.IdsReq
//@return: err error

func (operationRecordService *operationRecordService) DeleteSysOperationRecordByIds(ids request.IdsReq) (err error) {
	err = global.DBName(global.Log).Delete(&[]model.OperationLog{}, "id in (?)", ids.Ids).Error
	return err
}

//@description: 删除操作记录
//@param: sysOperationRecord model.SysOperationRecord
//@return: err error

func (operationRecordService *operationRecordService) DeleteSysOperationRecord(sysOperationRecord model.OperationLog) (err error) {
	err = global.DBName(global.Log).Delete(&sysOperationRecord).Error
	return err
}

//@description: 根据id获取单条操作记录
//@param: id uint
//@return: sysOperationRecord system.SysOperationRecord, err error

func (operationRecordService *operationRecordService) GetSysOperationRecord(id uint) (sysOperationRecord model.OperationLog, err error) {
	err = global.DBName(global.Log).Where("id = ?", id).First(&sysOperationRecord).Error
	return
}

//@function: GetSysOperationRecordInfoList
//@description: 分页获取操作记录列表
//@param: info systemReq.SysOperationRecordSearch
//@return: list interface{}, total int64, err error

func (operationRecordService *operationRecordService) GetSysOperationRecordInfoList(info request.SysOperationLogSearch) (list interface{}, total int64, err error) {
	limit := info.PageSize
	offset := info.PageSize * (info.Page - 1)
	// 创建db
	db := global.DBName(global.Log).Model(&model.OperationLog{})
	var sysOperationRecords []model.OperationLog
	// 如果有条件搜索 下方会自动创建搜索语句
	if info.Method != "" {
		db = db.Where("method = ?", info.Method)
	}
	if info.Path != "" {
		db = db.Where("path LIKE ?", "%"+info.Path+"%")
	}
	if info.Status != "" {
		db = db.Where("status = ?", info.Status)
	}
	err = db.Count(&total).Error
	if err != nil {
		return
	}
	err = db.Order("id desc").Limit(limit).Offset(offset).Preload("User").Find(&sysOperationRecords).Error
	return sysOperationRecords, total, err
}
