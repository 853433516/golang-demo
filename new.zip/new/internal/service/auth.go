package service

import (
	"PayOrder/global"
	"PayOrder/internal/dto"
	"PayOrder/internal/model"
	"PayOrder/pkg/utils/common"
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/gofrs/uuid"
	"github.com/pkg/errors"
	"gorm.io/gorm"
)

type authService struct{}

type iAuthService interface {
	Register(info *dto.Register) (*model.SysUser, error)
	Login(info *model.SysUser) (*model.SysUser, error)
	LogOut(c *gin.Context) error
	// AuthWebsocket 认证函数
	AuthWebsocket(token string) (uint, bool)
}

func newAuthService() iAuthService {
	auth := &authService{}
	//WebsocketService.OnAuth(auth.AuthWebsocket)
	return auth
}

func (u *authService) Register(r *dto.Register) (userInter *model.SysUser, err error) {
	user := &model.SysUser{
		Username:  r.Username,
		NickName:  r.NickName,
		Password:  r.Password,
		HeaderImg: r.HeaderImg,
		Enable:    r.Enable,
	}
	if !errors.Is(global.DBName(global.Buss).Where("username = ?", user.Username).First(&user).Error, gorm.ErrRecordNotFound) { // 判断用户名是否注册
		return userInter, errors.New("用户名已注册")
	}
	// 否则 附加uuid 密码hash加密 注册
	user.Password = common.BcryptHash(user.Password)
	user.UUID = uuid.Must(uuid.NewV4())
	err = global.DBName(global.Buss).Create(&user).Error
	return user, err
}

func (u *authService) Login(info *model.SysUser) (*model.SysUser, error) {
	if nil == global.DBName(global.Buss) {
		return nil, fmt.Errorf("db not init")
	}

	var user model.SysUser
	err := global.DBName(global.Buss).Where("username = ?", info.Username).First(&user).Error
	if err == nil {
		if ok := common.BcryptCheck(info.Password, user.Password); !ok {
			return nil, errors.New("密码错误")
		}
	}
	return &user, err
}

func (u *authService) LogOut(c *gin.Context) error {
	c.SetCookie("session", "", -1, "", "", false, false)
	return nil
}

func (u *authService) AuthWebsocket(token string) (uint, bool) {
	if cla, err := common.GetClaimsFromTokenStr(token); err != nil {
		return 0, false
	} else {
		return cla.BaseClaims.ID, true
	}
}
