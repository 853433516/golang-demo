package service

import (
	"PayOrder/global"
	"fmt"
	"time"
)

type alertSettingService struct{}

type iAlertSettingService interface {
	Create(hostId, userId uint) error
}

func newAlertSettingService() iAlertSettingService {
	return &alertSettingService{}
}

func (a *alertSettingService) Create(hostId, userId uint) error {
	global.LOG.Info(fmt.Sprintf("%s", time.DateTime))
	return nil
}
