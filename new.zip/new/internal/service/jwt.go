package service

import (
	"PayOrder/global"
	"PayOrder/internal/model"
	"PayOrder/pkg/utils/common"
	"context"

	"go.uber.org/zap"
)

type jwtService struct{}

type iJwtService interface {
	IsBlacklist(jwt string) bool
	GetRedisJWT(userName string) (redisJWT string, err error)
	JsonInBlacklist(jwtList model.JwtBlacklist) (err error)
	SetRedisJWT(jwt string, userName string) (err error)
}

func newJwtService() iJwtService {
	return &jwtService{}
}

//@description: 拉黑jwt
//@param: jwtList model.JwtBlacklist
//@return: err error

func (jwtService *jwtService) JsonInBlacklist(jwtList model.JwtBlacklist) (err error) {
	err = global.DBName(global.Buss).Create(&jwtList).Error
	if err != nil {
		return
	}
	global.BlackCache.SetDefault(jwtList.Jwt, struct{}{})
	return
}

//@description: 判断JWT是否在黑名单内部
//@param: jwt string
//@return: bool

func (jwtService *jwtService) IsBlacklist(jwt string) bool {
	_, ok := global.BlackCache.Get(jwt)
	return ok
	// err := global.GVA_DB.Where("jwt = ?", jwt).First(&system.JwtBlacklist{}).Error
	// isNotFound := errors.Is(err, gorm.ErrRecordNotFound)
	// return !isNotFound
}

//@description: 从redis取jwt
//@param: userName string
//@return: redisJWT string, err error

func (jwtService *jwtService) GetRedisJWT(userName string) (redisJWT string, err error) {
	redisJWT, err = global.Redis.Get(context.Background(), userName).Result()
	return redisJWT, err
}

//@description: jwt存入redis并设置过期时间
//@param: jwt string, userName string
//@return: err error

func (jwtService *jwtService) SetRedisJWT(jwt string, userName string) (err error) {
	// 此处过期时间等于jwt过期时间
	dr, err := common.ParseDuration(global.Viper.Jwt.ExpiresTime)
	if err != nil {
		return err
	}
	timer := dr
	err = global.Redis.Set(context.Background(), userName, jwt, timer).Err()
	return err
}

func LoadAll() {
	var data []string
	err := global.DBName(global.Buss).Model(&model.JwtBlacklist{}).Select("jwt").Find(&data).Error
	if err != nil {
		global.LOG.Error("加载数据库jwt黑名单失败!", zap.Error(err))
		return
	}
	for i := 0; i < len(data); i++ {
		global.BlackCache.SetDefault(data[i], struct{}{})
	} // jwt黑名单 加入 BlackCache 中
}
