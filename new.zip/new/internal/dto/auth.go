package dto

import (
	"PayOrder/internal/model"
)

type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type Register struct {
	Username     string `json:"userName" example:"用户名"`
	Password     string `json:"passWord" example:"密码"`
	NickName     string `json:"nickName" example:"昵称"`
	HeaderImg    string `json:"headerImg" example:"头像链接"`
	Bot          string `json:"bot"`
	AuthorityId  uint   `json:"authorityId" example:"int 角色id"`
	Enable       bool   `json:"enable"`
	AuthorityIds []uint `json:"authorityIds" example:"[]uint 角色id"`
	UserId       uint   `json:"userId" example:"创建的用户ID;"`
	ServersNum   uint   `json:"serversNum" example:"允许创建最大服务器数量;"`
	EmployeesNum uint   `json:"employeesNum" example:"允许创建最大员工数量;"`
	RoleId       uint   `json:"role_id"`
}

type SysUserResponse struct {
	User model.SysUser `json:"user"`
}

type LoginResponse struct {
	User      model.SysUser `json:"user"`
	Token     string        `json:"token"`
	ExpiresAt int64         `json:"expiresAt"`
}

// Modify password structure
type ChangePasswordReq struct {
	ID       uint   `json:"id"`       // 从 JWT 中提取 user id，避免越权
	Password string `json:"password"` // 密码
	//NewPassword string `json:"newPassword"` // 新密码
}

// Modify password structure
type ChangePasswordReqNew struct {
	ID          uint   `json:"id"`          // 从 JWT 中提取 user id，避免越权
	Password    string `json:"password"`    // 密码
	NewPassword string `json:"newPassword"` // 新密码
}

type ChangeUserInfo struct {
	ID           uint   `json:"id"` // 主键ID
	UserName     string `json:"userName"`
	NickName     string `json:"nickName"` // 用户昵称
	ServersNum   uint   `json:"serversNum"`
	EmployeesNum uint   `json:"employeesNum"`
	HeaderImg    string `json:"headerImg"` // 用户头像
	Enable       bool   `json:"enable"`    //冻结用户
	RoleId       uint   `json:"role_id"`
}

type RoleCreate struct {
	Name   string `json:"name"  binding:"required"`
	Remark string `json:"remark"`
	Status bool   `json:"status"  binding:"required"`
}

type RoleUpdate struct {
	ID     uint   `json:"ID"`
	Name   string `json:"name"`
	Remark string `json:"remark"`
	Status bool   `json:"status"`
}
