package middleware

// 保留IP請求頭
//, "x-real-ip", "x-forwarded", "forwarded-for",
//"forwarded", "true-client-ip", "client-ip", "ali-cdn-real-ip",
//"cdn-src-ip", "cdn-real-ip", "x-cluster-client-ip",
//"wl-proxy-client-ip", "proxy-client-ip", "true-client-ip",

//var (
//	RealIPHeaders = []string{
//		"cf-connecting-ip",
//	}
//)
//
//func AreaVisitHook() gin.HandlerFunc {
//	ipFilter := global.QQZengIpSearcher
//	return func(c *gin.Context) {
//		var (
//			IP         = ""
//			result     = make([]int, 4)
//			area       string
//			areaResult []string
//			country    model.CountryCode
//			err        error
//		)
//
//		for i, v := range RealIPHeaders {
//			IP = c.GetHeader(v)
//			if len(IP) > 0 {
//				break
//			} else if i == len(RealIPHeaders)-1 {
//				IP = c.ClientIP()
//			}
//		}
//		ips := strings.Split(IP, ".")
//
//		// 放行IPv6
//		if ip := net.ParseIP(IP); ip == nil || ip.To4() == nil {
//			goto allow
//		}
//
//		if strings.Index(IP, "192.168.") == 0 {
//			goto allow
//		}
//
//		if result[0], err = strconv.Atoi(ips[0]); err != nil {
//			goto refuse
//		}
//		if result[1], err = strconv.Atoi(ips[1]); err != nil {
//			goto refuse
//		}
//		if result[2], err = strconv.Atoi(ips[2]); err != nil {
//			goto refuse
//		}
//		if result[3], err = strconv.Atoi(ips[3]); err != nil {
//			goto refuse
//		}
//
//		if area = ipFilter.Get(uint32(result[0]), uint32(result[1]), uint32(result[2]), uint32(result[3])); len(area) == 0 {
//			goto refuse
//		}
//
//		if len(area) == 0 {
//			goto allow
//		}
//
//		areaResult = strings.Split(area, "|")
//		country, err = repo.CountryCodeRepo.Get(repo.CommonRepo.WithByStringField("code", areaResult[len(areaResult)-3]))
//		if err == gorm.ErrRecordNotFound {
//			global.LOG.Error("查询国家记录失败: " + err.Error())
//			goto refuse
//		}
//		if !country.Allow {
//			goto refuse
//		}
//	allow:
//		c.Next()
//		return
//	refuse:
//		c.JSON(501, map[string]interface{}{
//			"code": 7,
//			"data": map[string]interface{}{
//				"ip":     IP,
//				"code":   areaResult[len(areaResult)-3],
//				"failed": err != nil,
//				"error":  fmt.Errorf("查询国家记录失败: %v", err),
//			},
//			"msg": "您目前地区不受支持",
//		})
//		c.Abort()
//	}
//}
