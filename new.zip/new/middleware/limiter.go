package middleware

import (
	"github.com/gin-gonic/gin"
	"github.com/go-kratos/aegis/ratelimit/bbr"
)

func BRRLimiter(cpuUsageRate int64) gin.HandlerFunc {
	limiter := bbr.NewLimiter(
		bbr.WithCPUThreshold(cpuUsageRate),
	)
	return func(ctx *gin.Context) {
		//fmt.Printf("Emit Limiter CPU Usage : %d\n", limiter.Stat().CPU)
		if _, err := limiter.Allow(); err != nil {
			ctx.JSON(506, map[string]interface{}{"code": 506, "msg": "请求超限", "data": limiter.Stat().CPU})
			ctx.Abort()
			return
		}
		ctx.Next()
	}
}
