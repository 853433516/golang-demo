package global

import (
	"PayOrder/initialize/viper/config"
	"sync"

	"github.com/redis/go-redis/v9"
	"github.com/songzhibin97/gkit/cache/local_cache"
	"go.uber.org/zap"
	"golang.org/x/sync/singleflight"
	"gorm.io/gorm"
)

const (
	Buss = "seo"
	Log  = "op_log"
)

var (
	// LOG DB 数据库连接管理
	DBMap              map[string]*gorm.DB
	DB                 *gorm.DB
	LOG                *zap.Logger
	Viper              *config.Config
	Redis              *redis.Client
	ConcurrencyControl = &singleflight.Group{}
	lock               sync.RWMutex
	BlackCache         local_cache.Cache
)

// DBName 通过名称获取db list中的db
func DBName(dbname string) *gorm.DB {
	lock.RLock()
	defer lock.RUnlock()
	db, ok := DBMap[dbname]
	if !ok || db == nil {
		panic("数据库初始化失败")
	}
	return DBMap[dbname]
}
