package constant

import "path"

var (
	SystemConfigDirPath = "./config"
	SystemConfigPath    = path.Join(SystemConfigDirPath, "config.yml")
)
