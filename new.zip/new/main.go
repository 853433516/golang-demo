package main

import (
	"PayOrder/cmd"
)

func main() {
	cmd.Execute()
}
